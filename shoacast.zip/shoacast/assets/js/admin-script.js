jQuery(document).ready(function ($) {
   
    
    $(document).on("click", ".guest-select-avatar", function (event) {
        
        var frame;
        var file_link_input = $(this).closest(".form-field").find(".shoa-guest-avatar");
        var avatar_show_image = $(this).closest(".form-field").find(".guest-select-avatar-img");
        event.preventDefault();

        if (frame) {
        frame.open();
        return;
        }

        frame = wp.media({
        title: "تصویر مهمان را انتخاب کنید",
        button: {
            text: "انتخاب تصویر",
        },
        multiple: false,
        });

        frame.on("select", function () {
        var attachment = frame.state().get("selection").first().toJSON();
        
        file_link_input.val(attachment.url);
        avatar_show_image.attr( "src" , attachment.url);
        // imgIdInput.val(attachment.id);
        });

        frame.open();
        
    });


});