<?php
    $sound_url = get_post_meta($post->ID , "shoa_sound_file_url" , true);
    $video_url = get_post_meta($post->ID , "shoa_video_file_url" , true);
    $part_number = get_post_meta($post->ID , "shoa_part_number" , true);
    $shoa_subtitle = get_post_meta($post->ID , "shoa_subtitle" , true);
?>



<div class="meta_details">

    <div>
        <label>شماره قسمت</label>
        <input type="text" name="shoa_part_number" placeholder="شماره قسمت" value="<?php echo $part_number; ?>">
    </div>

    <div>
        <label>زیر عنوان</label>
        <input type="text" name="shoa_subtitle" placeholder="زیر عنوان (اختیاری)" value="<?php echo $shoa_subtitle; ?>">
    </div>

</div>

<div class="meta_details">

    <div>
        <label>لینک فایل صوتی</label>
        <input type="text" name="shoa_sound_file_url" placeholder="https://" dir="ltr" value="<?php echo $sound_url; ?>">
    </div>

    <div>
        <label>لینک فایل ویدئویی یا شناسه آپارات</label>
        <input type="text" name="shoa_video_file_url" placeholder="https://     Or     aparat video ID" dir="ltr" value="<?php echo $video_url; ?>">
    </div>

</div>



<?php

wp_enqueue_style("shoa_admin_style");
wp_enqueue_script("shoa_admin_script");