<?php

add_action("wp_enqueue_scripts" , "shoacast_register_assets");
add_shortcode("shoa_podcast" ,  "shoa_podcast_shortcode_content");
add_shortcode("shoa_podcast_subscribe_form" ,  "shoa_podcast_subscribe_form_content");



function shoacast_register_assets(){
        //for frontend user
    wp_register_script("shoa_script" , SHOA_URI . '/assets/js/script.min.js' , ['jquery'] , SHOA_VER , true);
    wp_register_style("shoa_style" , SHOA_URI . '/assets/css/style.css' , [] , SHOA_VER );
}

function shoa_podcast_shortcode_content($atts){
    ob_start();
    include SHOA_PATH . 'template/podcast-shortcode.php';

    wp_enqueue_style("shoa_style");
    
    wp_localize_script("shoa_script" , "SHOA_DATA" , [
        'ajax_url' => admin_url("admin-ajax.php"),
        'podcasts' => get_shoa_podcasts(),
        'guests' => get_guests(),
    ]);
    wp_enqueue_script("shoa_script");

    return ob_get_clean();
}


function shoa_podcast_subscribe_form_content(){
    ob_start();

    ?>

    <form class="shoa_subscribe_notif_form">
        <input type="email" placeholder="برای اطلاع از آخرین قسمت منتشر شده ایمیل خود را وارد کنید" >
        <button type="submit" class="subscribe_notifications">ارسال درخواست</button>
    </form>

    <?php

    return ob_get_clean();
}

function get_guests(){
    $guests = get_terms([
        'taxonomy' => 'shoa_guests',
        'hide_empty' => false,
        'parent'   => 0,
        'orderby'      => 'term_order',
        'order'          => 'ASC'
    ]);

    foreach ($guests as $guest){
        $guest->avatar = get_term_meta($guest->term_id , "shoa-guest-avatar" , true);
        $guest->position = get_term_meta($guest->term_id , "shoa-guest-position" , true);
    }

    return $guests;
}


function get_shoa_podcasts(){


    $podcasts = get_posts([
        'post_type' => 'shoa-podcast',
        'status' => 'publish',
        'numberposts' => -1,
    ]);
    
    $return = [];

    foreach($podcasts as $podcast){

        $object = new stdClass;
        $object->id         = $podcast->ID;
        $object->image      = get_the_post_thumbnail_url($podcast->ID);
        $object->title      = get_podcast_title($podcast->ID);
        $object->part_name  = get_podcast_part_name($podcast->ID);
        $object->guest      = get_podcast_guest($podcast->ID);
        $object->audio_url  = get_post_meta($podcast->ID , "shoa_sound_file_url" , true);
        $object->video_url  = get_post_meta($podcast->ID , "shoa_video_file_url" , true);
        $object->share_url  = get_the_permalink($podcast->ID);
        $object->created_at  = $podcast->post_date_gmt;

        $return[] = $object;

    }

    return $return;

}


function get_podcast_title($post_id){
    $shoa_subtitle = get_post_meta($post_id , "shoa_subtitle" ,  true);
    $terms = get_the_terms( $post_id , 'shoa_session' );
    $term_title = isset($terms[0]) && is_object($terms[0]) ? get_term_meta( $terms[0]->term_id, 'shoa-session-title', true ) : '';
    if(isset($shoa_subtitle) && !empty($shoa_subtitle)){
        $term_title = $shoa_subtitle;
    }

    return $term_title;
}


function get_podcast_part_name($post_id){

    $term_session = get_the_terms($post_id , "shoa_session");

    if(!isset($term_session[0])){
        return '';
    }

    $session_name = $term_session[0]->name;

    $part_number = get_post_meta($post_id , "shoa_part_number" , true);

    return "$session_name - قسمت $part_number";
}


function get_podcast_guest($post_id){
    
    $term_guest = get_the_terms($post_id , "shoa_guests");

    if(!isset($term_guest[0])){
        return '';
    }

    $position = get_term_meta($term_guest[0]->term_id , "shoa-guest-position" , true);

    return [
        'id' => $term_guest[0]->term_id,
        'fullname' => $term_guest[0]->name,
        'position' => $position,
    ];

}